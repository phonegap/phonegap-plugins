Phonegap-BarcodeScanner-ios Updated
===========================

Barcode Scanner for Cordova Phonegap 2.6+
iOS Support

Based on https://github.com/phonegap/phonegap-plugins/tree/master/iOS

@daynatem Salvador Almaraz

