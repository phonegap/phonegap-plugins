var app = {
    initialize: function() {
        this.bind();
    },
    bind: function() {
        document.addEventListener('deviceready', this.deviceready, false);
    },
    deviceready: function() {
        // note that this is an event handler so the scope is that of the event
        // so we need to call app.report(), and not this.report()
        app.report('deviceready');
        
        try {
            
            // do your thing!
            document.addEventListener(PayPal.PaymentEvent.Success, onPaymentSuccess,false);
            document.addEventListener(PayPal.PaymentEvent.Canceled, onPaymentCanceled,false);
            document.addEventListener(PayPal.PaymentEvent.Failed, onPaymentFailed,false);
            
            window.plugins.paypal.prepare(PayPal.PaymentType.DONATION);
            window.plugins.paypal.setPaymentInfo({
                                                 paymentCurrency : "USD",
                                                 paymentAmount : "10.00",
                                                 itemDesc : "PhoneGap iOS Plugin Maintanance",
                                                 recipient : "randy.lee.mcmillan@gmail.com",
                                                 merchantName : "Randy McMillan"
                                                 });
            
		} catch (e) {
			debug.error(e);
		}
        
        
    },
    report: function(id) { 
        console.log("report:" + id);
        // hide the .pending <p> and show the .complete <p>
        document.querySelector('#' + id + ' .pending').className += ' hide';
        var completeElem = document.querySelector('#' + id + ' .complete');
        completeElem.className = completeElem.className.split('hide').join('');
    }
};
